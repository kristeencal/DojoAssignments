// Get schema from models
var Post = mongoose.model('Post');

module.exports = {
  show: function(req, res) {
    
  }
}
